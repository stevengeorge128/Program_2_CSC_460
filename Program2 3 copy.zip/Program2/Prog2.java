
/**---------------------------------------------------------------------
 * Assignment:      Program 2
 * 
 * Author:          Steven George
 *                  Also credit to Dr. Lester McCann for IO example used as 
 *                  basis for working with RandomAccessFile objects
 * 
 * Course:          CSC 360 Database Design Spring 2025
 * Instructor:      Dr. Lester McCann
 * TA's:            Xinyu (Joyce) Guo, Jianwei (James) Shen
 * Due Date:        13 February 2025 at the start of class
 * 
 * Language:        Java (Java SE 16.0.2)
 * Packages:        java.io
 *      			java.util.*
 * 
 * Compile/Run:     Ensure Field.java file included in pwd. Ensure .bin file exists by running part A
 *					JDK:    Compile: javac *.java
 *                  Run:    java Prog2
 * 
 * ---------------------------------------------------------------------
 * 
 * Description:     Taking the input binary file of Prog1A as input, this 
 *                  program reads the binary file into a tree using dynamic 
 *                  hashing according to Dr. McCann's definition such that
 *                  a tree is created where each leaf represents a value 
 *                  in the index being stored and contains a reference 
 *                  to a byte location where that info is stored in a binary 
 *                  file. Each level in the tree is +1 index working backwards 
 *                  from the end of the index. Buckets contain all values 
 *                  that contain their specific value for their specific index.
 *                  Once the tree is created the user can query by suffixes for 
 *                  any runner id's that match the input suffix. A runner 
 *                  id "12345678" has suffixes 8, 78, ..., 12345678
 * 
 * Input:           The filepath to the binary .bin file created by Prog1A
 * 
 * Output:          See description. The results of any queries by the user 
 *                  are printed to the console.
 * 
 * Techniques:      1. Gather input from the user and create the binary file 
 *                  to store the hash buckets
 * 
 *                  2. For each line in the input data binary file, parse the line 
 *                  and add it to the tree
 * 
 *                  2a. To add a line to the tree find its id, then work backwards from 
 *                  its last digit to traverse through the tree to find the leaf node 
 *                  that matches with the current digit. That could be the last digit 
 *                  of the id all the way up until the first digit. 
 * 
 *                  2b. While adding, if the hash bucket contains n elements where n is 
 *                  the size of the bucket, then the bucket is resized by creating 
 *                  10 new leafs in the tree and using the next digit in the ids from the
 *                  full tree to assign the ids to new leaf nodes/buckets.
 * 
 *                  3. Prompt the user for queries. For each query start at the last digit
 *                  and work to the front for as long as the query is or till a leaf node 
 *                  is reached and use that digit to find the next node in the tree. Then
 *                  print every id related to that node by gathering the offsets from 
 *                  the hash bucket binary file and going to that location in the 
 *                  data binary file.
 * 
 *                  3a. If a leaf node is reached but not the end of the query then 
 *                  the found leaf node may contain ids that do not fully contain the 
 *                  queries suffix. In this case the end of the ids are checked before 
 *                  being output.
 * ---------------------------------------------------------------------*/

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.ArrayDeque;

import java.util.Scanner;

public class Prog2 {

    private HashNode root;
    private RandomAccessFile bucketBin;
    private RandomAccessFile dataBin;
    private int bucketSize = 100;
    private int bucketFileLineSize = 12;
    private int[] fieldLengths;
    private ArrayList<Long> usedOffsets = new ArrayList<>(1000);

    /*
     * init) Check if the bin file in the input exists, if not then we have an
     * issue. Then try to create the hash bucket file, if we cannot do that we also
     * have an issue 1) Create the root node which should just be a reference to the
     * hashNode class 2) Initialize the first 10 nodes of the hashNode tree. These
     * should be sequential and contain a reference to the next node, a pointer to
     * where they refer to in the hash bucket file, or a pointer to the next node in
     * the tree if another level has been added. The root should just contain an
     * array pointing to each of the 10 children. This will be an arrayList. This
     * class should take its number when being initialized ?) Read in the file
     * produced by program 1A line by line using a RandomAccessFile and the process
     * used in Prog1B.java . Should not have to do a lot here
     * 
     * 
     * 
     * 
     * 
     */

    public static void main(String[] args) {

        Prog2 program = new Prog2();
        program.start();
    }
    /*---------------------------------------------------------------------
     * Method	
     * 
     * Purpose: 
     * 
     * Pre-condition: 	
     * 
     * Post-condition:	
     * 
     * Parameters:	
     * 
     * Returns: 
     * 
     *---------------------------------------------------------------------*/

    /*---------------------------------------------------------------------
     * Method	start
     * 
     * Purpose: Initialize the root node of the tree. Call the appropriate functions
     * 			to initialize the hash bucket binary file. Call the appropriate functions
     * 			to read in the data binary file and begin data processing. Begin querying
     * 			after the data structure has been initialized.
     * 
     * Pre-condition: 	None
     * 
     * Post-condition:	User input binary file is read and data structure created allowing 
     * 					querying to begin
     * 
     * Parameters:	None
     * 
     * Returns: None
     * 
     *---------------------------------------------------------------------*/
    private void start() {

        Scanner scanner = new Scanner(System.in);
        // System.out.println("Enter the binary file filepath");
        String filepath = scanner.nextLine();
        this.dataBin = this.initializeDataBinFile(filepath);
        this.bucketBin = this.initializeBucketBinaryFile();

        // Error
        if (this.bucketBin == null) {
            System.out.println("ERROR: Failed to create bucket binary file");
            System.exit(-1);
        }

        // Root node initialized with 10 children who do not have file pointers nor
        // children
        this.root = this.initializeRootNode();

        // Set each child to have an offset position in the bin file
        try {
            this.setChildrenOffsets(this.root, 0, this.bucketBin.length());
        } catch (IOException e) {
            System.out.println("ERROR: Could not get bucket binary file length");
            System.exit(-1);
        }

        // Error check for null tree or files
        if (this.root == null || this.bucketBin == null || this.dataBin == null) {
            System.out.println("ERROR: Failure to initialize");
            System.exit(-1);
        }

        // Read data and begin querying
        this.readInData();
        this.beginQuerying();
        this.closeFiles();
        scanner.close();

    }

    /*---------------------------------------------------------------------
     * Method 	initializeRootNode
     * 
     * Purpose:	Initialize the root HashNode and its 10 children by creating
     * 			each object and storing in the root ArrayList. Children will 
     * 			be assigned values but not file pointers or children yet.
     * 
     * Pre-condition:	Root has not been initialized because it will be reassigned
     * 
     * Post-condition:	Root and its 10 initial children are created
     * 
     * Parameters:	None
     * 
     * Returns:	HashNode to be assigned to root
     * 
     *---------------------------------------------------------------------*/
    private HashNode initializeRootNode() {
        HashNode rootNode = new HashNode(null, 0);
        rootNode.setLevel(0);
        rootNode.createChildren();
        return rootNode;
    }

    /*---------------------------------------------------------------------
     * Method 	setChildrenOffsets
     * 
     * Purpose:	Take a hashnode and two byte locations and evenly assign those
     * 			byte locations to each hashnode to create buckets in the binary 
     * 			bucket file
     * 
     * Pre-condition:	this.bucketBin has been initialized. this.root has
     * 					been initialized. end - start can evenly be divided 
     *                  into the 10 bucket sections.
     * 
     * Post-condition:	Each hashNode is assigned a unique byte offset
     * 
     * Parameters:	
     *      node -- HashNode to get children HashNodes from
     *      start -- long byte location
     *      end -- long byte locations
     * 
     * Returns:	 void
     * 
     *---------------------------------------------------------------------*/
    private void setChildrenOffsets(HashNode node, long start, long end) {
        // Check for even distribution
        if ((this.bucketSize * 12 * 10) != (end - start)) {
            System.out.println("ERROR: Invalid start and end in setChildrenOffsets");
            System.exit(-1);
        }
        long step = this.bucketSize * 12;
        for (int i = 0; i < 10; i++) {
            // For each of the 10 offsets in the binary file
            // assign those offset to the given HashNode
            HashNode child = node.getChild(i);
            if (child == null) {
                System.out.println("ERROR: Tried to get null child.");
                System.exit(-1);
            }
            // Calculate offset based on step
            Long offset = start + (i * step);

            // If the offset has been used we have a major issue
            if (this.usedOffsets.contains(offset)) {
                print("ERROR: Offset is not unique");
                System.exit(-1);
            }
            usedOffsets.add(offset);
            child.setChildOffset(offset);
        }

    }

    /*---------------------------------------------------------------------
     * Method 	initializeBucketBinaryFile
     * 
     * Purpose:	Initialize the RandomAccessFile used to store the hash bucket 
     * 			index-offset pairs. The file is initialized to 
     * 			bucketSize [rows per bucket] * 10 [buckets] * this.bucketFileLineSize
     *          [bytes per row]
     * 
     * Pre-condition:   None
     * 
     * Post-condition:	bucketBinaryFile is initialized to the required size 
     * 					for the initial set of buckets
     * 
     * Parameters:	None
     * 
     * Returns:	RandomAccessFile reference containing each bucket
     * 
     *---------------------------------------------------------------------*/
    private RandomAccessFile initializeBucketBinaryFile() {

        File binFileRef = null; // Used to check if bin file already exists and delete it
        RandomAccessFile binFile = null;
        // Check for and delete existing version
        try {
            binFileRef = new File("bucket.bin");
            if (binFileRef.exists())
                binFileRef.delete();
        } catch (Exception e) {
            System.out.println("ERROR: Could not delete previous instance of .bin file");
            System.exit(-1);
        }

        // Create and return the bin file
        try {
            binFile = new RandomAccessFile("bucket.bin", "rw");
            binFile.setLength(bucketSize * 10 * this.bucketFileLineSize); // Preallocate initial size
            return binFile;
        } catch (FileNotFoundException e) {
            System.out.println("ERROR: FileNotFoundException - Could not generate bucket binary file");
            System.exit(-1);
        } catch (IOException e) {
            System.out.println("ERROR - IOException - Could not set bucket binary file length");
            System.exit(-1);
        }
        return binFile;

    }

    /*---------------------------------------------------------------------
     * Method 	initializeDataBinFile
     * 
     * Purpose:	Take the name of the binary file containing the data from 
     * 			the command line and open it as a RandomAccessFile in read mode
     * 
     * Pre-condition:	None
     * 
     * Post-condition:	The user input data binary file is stored in a RandomAccessFile 
     *                  reference
     * 
     * Parameters:	
     *      path -- String path to data binary file
     * 
     * Returns:	Reference to the RandomAccessFile
     * 
     *---------------------------------------------------------------------*/
    private RandomAccessFile initializeDataBinFile(String path) {
        try {
            RandomAccessFile file = new RandomAccessFile(path, "r");
            return file;
        } catch (FileNotFoundException e) {
            System.out.println("ERROR: Could not find binary file");
            System.exit(-1);
        }
        return null;
    }

    /*---------------------------------------------------------------------
     * Method 	readInData
     * 
     * Purpose:	Sequentially iterate through this.dataBin and add the data 
     * 			to the tree data structure by appropriately parsing the data 
     * 			and adding to the correctHash node, calling resize when necessary
     * 
     * Pre-condition:	this.dataBin and this.hashBin have been initialized
     * 
     * Post-condition:	all data in this.dataBin stored in the tree and hashBin
     * 
     * Parameters:	None
     * 
     * Returns:	None
     * 
     *---------------------------------------------------------------------*/
    private void readInData() {
        // Get the number of bytes
        long totalBytes = 0;
        try {
            totalBytes = this.dataBin.length();
        } catch (IOException e) {
            System.out.println("ERROR: Could not read binary file length");
            System.exit(-1);
        }

        // Move to the end of the file and read the last byte to get the number of 
        // fields in a record
        int numberOfFields = -1;
        try {
            this.dataBin.seek(totalBytes - 4);
            numberOfFields = this.dataBin.readInt();

        } catch (IOException e) {
            System.out.println("ERROR: Could not read last byte of binary file");
            System.exit(-1);
        }

        // Read backwards for the number of fields to get the length of each field,
        // the data length, and the length of each line
        this.fieldLengths = getFieldLengthsArray(totalBytes, numberOfFields);

        // Data length is total bytes minus int marking number of fields
        // minus number of ints used for field lengths
        long dataLengthExcludingHeaders = totalBytes - 4 - numberOfFields * 4;
        int lineLength = 0;

        // Sum up field lengths to get line length
        for (int j = 0; j < fieldLengths.length; j++) {
            lineLength += fieldLengths[j] == -1 ? 4 : fieldLengths[j];
        }
        
        // For each line read it into String array and call addToTree on that line
        String[] lineStringList = new String[fieldLengths.length];
        for (long l = 0; l < dataLengthExcludingHeaders; l += lineLength) {
            this.readBinFileLineIntoStringArr(fieldLengths, lineStringList, l);
            // check runner id not empty or 0 because Prog1A enters empty runner ids as 0
            if (lineStringList[0].length() != 0 && (lineStringList[0].compareTo("0") != 0)) {
                this.addToTree(lineStringList, l);
            }
        }
    }

    /*---------------------------------------------------------------------
     * Method	
     * 
     * Purpose: 
     * 
     * Pre-condition: 	
     * 
     * Post-condition:	
     * 
     * Parameters:	
     * 
     * Returns: 
     * 
     *---------------------------------------------------------------------*/
    private void addToTree(String[] lineStringList, long positionInDataBinFile) {
        // Parse the runner id into an integer. Exit if that fails
        int level = 1;
        int id;
        try {
            id = Integer.parseInt(lineStringList[0]);
        } catch (Exception e) {
            System.out.println("ERROR: Runner id not an int");
            return;
        }
        
        // Initialize boolean to check for loop condition, idString to get each digit from
        // index to know which digit in idString the loop is on, and currentNode by getting
        // the child of root that corresponds with the last digit of idString
        boolean atLeafNode = false;
        String idString = lineStringList[0];
        int index = idString.length() - 1;
        HashNode currentNode = root.getChild(Integer.parseInt(idString.substring(index, index + 1)));
        // While we have not yet reached the end of the tree
        while (!atLeafNode) {
            // While not at leaf, check if valid index, check if leaf. 
            // If it is a leaf stop iterating and add the idString to the hash bucket 
            // file. First resize if the data count of the node is equal to the bucket size.
            // If not a leaf, decrement index and get the child of currentNode that corresponds
            // with idString[index]
            if (index < 0) {
                print("ERROR: OUT OF BOUNDS INDEX");
                System.exit(-1);
            }
            if (currentNode.isLeaf()) { // If we reached a leaf node stop iterating
                atLeafNode = true;
                if (currentNode.getDataCount() == this.bucketSize) { // Resize if the tree if full
                    this.resizeNode(currentNode, id, level + 1);
                    atLeafNode = false;
                    index--;
                    if (index < 0) {
                        print("ERROR: OUT OF BOUNDS INDEX");
                        System.exit(-1);
                    }
                    currentNode = currentNode.getChild(Integer.parseInt(idString.substring(index, index + 1)));
                }
            } else { // Move to next level of tree
                index--;
                if (index < 0) {
                    print("ERROR: OUT OF BOUNDS INDEX");
                    System.exit(-1);
                }
                currentNode = currentNode.getChild(Integer.parseInt(idString.substring(index, index + 1)));
            }
            level++;
        }
        // positionInBinFile is the offset of current node + the size of each line in the hash
        // bucket binary file times the number of elements in the current node. 
        long positionInBinFile = currentNode.getOffset() + (this.bucketFileLineSize * currentNode.getDataCount());

        writeIdAndOffsetToBinFile(positionInDataBinFile, id, currentNode, positionInBinFile);

    }

    private void print(String s) {
        System.out.println(s);
    }

    /*---------------------------------------------------------------------
     * Method	writeIdAndOffsetToBinFile
     * 
     * Purpose: Write the given runnerId and byte location in the data binary file 
     *          to the hash bucket binary file using the given position in the 
     *          hash bucket binary file. Also increment the number of elements 
     *          inside the current node. Always write int then long
     * 
     * Pre-condition: 	currentNode not null. positionInBucketBinFile is initialized 
     *                  and unique location. 
     * 
     * Post-condition:	the given id and position in the data bin file are 
     *                  written to the hash bucket binary file
     * 
     * Parameters:	
     *      positionInDataBinFile -- Long position in data binary file to write
     *      id -- int id to write 
     *      currentNode -- HashNode to increment data count of after writing
     *      positionInBucketBinFile -- long position to write to in hash bucket binary file
     *      
     * Returns: void
     * 
     *---------------------------------------------------------------------*/
    private void writeIdAndOffsetToBinFile(long positionInDataBinFile, int id, HashNode currentNode,
            long positionInBucketBinFile) {
        try {
            this.bucketBin.seek(positionInBucketBinFile);
            this.bucketBin.writeInt(id);
            this.bucketBin.writeLong(positionInDataBinFile);
            currentNode.incrDataCount();
        } catch (IOException e) {
            System.out.println("ERROR: Could not write to bucket binary file");
            System.exit(-1);
        }
    }

    /*---------------------------------------------------------------------
     * Method	resizeNode
     * 
     * Purpose: Resizes the tree at the given node by iterating through 
     *          each byte location the node references, storing the id and
     *          data offset in memory, adding 10 children to the node, and then
     *          iterating through each id looking at the next digit that has not
     *          been utilized to store each pair in a new node of the tree, where 
     *          they are then written back into the end of the hash bucket binary 
     *          file that the ten new nodes now reference.
     * 
     * Pre-condition: 	node is full. Level refers to the digit from the 
     *                  ids to use to assign the read in ids to new buckets
     * 
     * Post-condition:	The node as been resized such that the given node of 
     *                  size this.bucketSize now has 10 children of 
     *                  size this.bucketSize reference the distributed children of 
     *                  node
     * 
     * Parameters:	
     *      node -- HashNode to resize
     *      id -- int new id - really just used for error messages
     *      level -- int level in tree corresponding with index in idStrings to sort by
     *               when counting from the end
     * 
     * Returns: void
     * 
     *---------------------------------------------------------------------*/
    private void resizeNode(HashNode node, int id, int level) {
        String idString = String.valueOf(id);
        // If level is longer than idString then we cannot add more nodes
        if (level > idString.length()) {
            System.out.println(String.format("ERROR: Invalid index in runner id for level <%s> and idString <%s>",
                    level, idString));
            System.exit(-1);
        }

        // ArrayList to contain each id and offset from the portion of the hash bucket
        // file that are being resized using ValueOffsetPair objects
        ArrayList<ValueOffsetPair> dataFromHashBin = new ArrayList<>(this.bucketSize);
        
        // Get the offset of the node and how many elements it references
        long currentOffset = node.getOffset();
        int elemInNode = node.getDataCount();
        int idFromHashBin;
        long offsetFromHashBin;
        try {
            // Move to each of those elements and for each one, read the data from the
            // binary file and store in in dataFromHashBin
            this.bucketBin.seek(currentOffset);
            for (int i = 0; i < elemInNode; i++) {
                idFromHashBin = this.bucketBin.readInt();
                offsetFromHashBin = this.bucketBin.readLong();
                dataFromHashBin.add(new ValueOffsetPair(idFromHashBin, offsetFromHashBin));

            }
        } catch (Exception e) {
            System.out.println("ERROR: Could not read from hash bucket binary file while resizing");
        }

        resizeHelperToInitializeChildrenAndAssignByteOffsets(node);

        // For each child write their info from dataFromHashBin into the hash bucket
        // binary file
        resizeHelperToWriteDataFromHashBinArray(node, level, dataFromHashBin);

    }

    /*---------------------------------------------------------------------
     * Method	resizeHelperToInitializeChildrenAndAssignByteOffsets
     * 
     * Purpose: helper method for resize that sets the node being resized to empty,
     *          creates its children, extends the hash bucket binary file, calculates
     *          the start and end byte locations of the 10 new nodes, and evenly assigns
     *          those byte locations
     * 
     * Pre-condition: 	None
     * 
     * Post-condition:	node has 10 new children with evenly distribute unique byte
     *                  locations at the end of the hash bucket binary file
     * 
     * Parameters:	
     *      node -- HashNode to add children to
     * 
     * Returns: 
     * 
     *---------------------------------------------------------------------*/
    private void resizeHelperToInitializeChildrenAndAssignByteOffsets(HashNode node) {
        // Set the node to empty as it not longer is a leaf and create its 10 children
        node.setEmpty();
        node.createChildren();

        // Initialize variables to mark the start and end bytes of the children in the
        // hash bucket binary file
        long childrenStart = 0;
        long childrenEnd = 0;
        try {
            // Find the start and end locations of these 10 children and seek to that
            // location
            childrenStart = this.bucketBin.length();
            childrenEnd = childrenStart + bucketSize * 10 * this.bucketFileLineSize;
            this.bucketBin.seek(childrenEnd - 4);
            this.bucketBin.writeInt(0);

        } catch (IOException e) {
            System.out.println("ERROR: Could not extend hash bucket binary file");
            System.exit(-1);
        }
        // Assign the children offsets with error checking in case the 
        // new byte location is not at the end of the hash bucket binary file
        try {
            if (childrenEnd != this.bucketBin.length()) {
                System.out
                        .println("ERROR: not setting children offsets to the end of the hash bucket bin");
                System.exit(-1);
            }
        } catch (IOException e) {
            System.out.println("ERROR: Could not read hash bucket binary file length " +
                    "while assigning offsets");
            System.exit(-1);
        }

        // Set the children offsets
        this.setChildrenOffsets(node, childrenStart, childrenEnd);
    }

    /*---------------------------------------------------------------------
     * Method	resizeHelperToWriteDataFromHashBinArray
     * 
     * Purpose: helper method for resize that takes the array of ValueOffsetPairs and 
     *          writes each pair to its new location in the hash bucket binary file 
     *          by getting its sorting index from level, getting that digit from the id
     *          in the pair, and moving to the correct child of node which allows the 
     *          correct byte location to be written to
     * 
     * Pre-condition: 	node has 10 children initialized with byte locations added. 
     *                  level is a valid index in the idStrings, and 
     * 
     * Post-condition:	dataFromHashBin pairs are written to hash bucket binary file 
     *                  in new locations
     * 
     * Parameters:	
     *      node -- HashNode being resized containing references to 10 children req
     *      level -- int index in idString to sort on. index 1 is last  value String
     *      dataFromHashBin -- ArrayList<ValueOffsetPair> containing each id and byte
     *          location in the data file to be written
     * 
     * Returns: 
     * 
     *---------------------------------------------------------------------*/
    private void resizeHelperToWriteDataFromHashBinArray(HashNode node, int level, ArrayList<ValueOffsetPair> dataFromHashBin) {
        int substringStart;
        String indexString;
        HashNode leafNodeToAddTo;
        long positionInBinFile;

        // For each pair in dataFromHashBin
        for (ValueOffsetPair p : dataFromHashBin) {
            // Get the id from the pair, convert it to String and get the digit we are one
            // using level then convert that back to an int
            indexString = String.valueOf(p.getIndex());
            substringStart = indexString.length() - level;
            String relevantDigitString = null;
            try {
                relevantDigitString = indexString.substring(substringStart, substringStart + 1);
            } catch (Exception e) {
                System.out.println(
                        String.format("ERROR: Could not call substring for <%s> with index <%s> and level <%s>",
                                indexString, substringStart, level));
                e.printStackTrace();
                System.exit(-1);
            }
            int relevantDigit = Integer.parseInt(relevantDigitString);

            // Then get the node we are adding to using that digit and
            // find the position we should add our data to in the hash bucket bin file
            // and add it using writeIdAndOffsetToBinFile
            leafNodeToAddTo = node.getChild(relevantDigit);
            positionInBinFile = leafNodeToAddTo.getOffset() + (12 * leafNodeToAddTo.getDataCount());
            writeIdAndOffsetToBinFile(p.getOffset(), p.getIndex(), leafNodeToAddTo, positionInBinFile);
        }
    }

    /*---------------------------------------------------------------------
    |  Method getFieldLengthsArray
    |
    |  Purpose:	Read the binary file backwards from the last line, where 
    |			the last 4 bytes of the file is the number of fields, allowing
    |			this method to know the number of bytes to read backwards
    |			to get the length of each field. The lengths of each field are 
    |			placed into an int[] array. 
    |
    |  Pre-condition:	binFile is opened, numberOfRecords is the number 
    |					of bytes in the entire file, and numberOfFields
    |					is the last int of the file which tells this function
    |					how many times to iterate
    |
    |  Post-condition:	The byte lengths of each field is read into an int[] array
    |					and returned. Furthermore, -1 is stored in the array 
    |					for fields that are integers.
    |
    |  Parameters:
    |			binFile -- opened binary file to use seek on
    |			numberOfRecords - Number of bytes in the file
    |			numberOfFields - Number of ints to rread from the last line
    |
    |  Returns:  int[] array of field lengths 
    *-------------------------------------------------------------------*/
    private int[] getFieldLengthsArray(long numberOfRecords, int numberOfFields) {
        int[] fieldLengths = new int[numberOfFields];
        int i = numberOfFields;
        long pos = numberOfRecords - 8;
        while (i > 0) {

            try {
                this.dataBin.seek(pos);
                fieldLengths[i - 1] = this.dataBin.readInt();
            } catch (IOException e) {
                System.out.println("ERROR: Could not read field lengths from binary file ");
                System.exit(-1);
            }

            pos -= 4;
            i--;
        }
        return fieldLengths;
    }

    /*---------------------------------------------------------------------
    |  Method readBinFileLineIntoArrayList
    |
    |  Purpose:	Take the bin file and an array to place the contents of the bin
    |			file into and read the number of bytes equivalent to the 
    |			lengths in fieldLength int[] array. If a -1 in field lengths 
    |			then 4 bytes are read, else the number of bytes in field lengths is read.
    |			This data is either read using readInt() or by creating 
    |			a byte array and converting it to a String. 
    |
    |  Pre-condition:	The binary file is open and lineStringList has been
    |					establish such that each field in the line can 
    |					be stored in it.
    |
    |  Post-condition:	lineStringList is updated to contain each field 
    |					of the line given by position. 
    |
    |  Parameters:
    |			binFile - the opened RandomAccessFile to read from
    |			fieldLengths - an int array containing the length of each field in 
    |				the line, with -1 representing ints, and all other values 
    |				representing strings.
    |			lineStringList - The established array to store the line info in
    |			position - a long marking the byte location of the line to read
    |				from in the file.
    |
    |  Returns:  void
    *-------------------------------------------------------------------*/
    private void readBinFileLineIntoStringArr(int[] fieldLengths, String[] lineStringList, long position) {
        try {
            // Seek to given position
            this.dataBin.seek(position);
            byte[] lineBytes = null;
            // For each value in fieldLengths, read either an int or a string using a 
            // byte array depending on whether fieldLengths contains -1 for ints or 
            // an int >0 for strings
            for (int k = 0; k < fieldLengths.length; k++) {
                if (fieldLengths[k] == -1) {
                    lineStringList[k] = Integer.toString(this.dataBin.readInt());
                } else {
                    lineBytes = new byte[fieldLengths[k]];
                    this.dataBin.readFully(lineBytes);
                    lineStringList[k] = new String(lineBytes);
                }

            }

        } catch (Exception e) {
            System.out.println("ERROR: Could not parse the binary file line");
            e.printStackTrace();
            System.exit(-1);

        }
    }

    /*---------------------------------------------------------------------
     * Method 	beginQuerying
     * 
     * Purpose:	Prompt the user to begin inputting queries allowing them 
     * 			to search for data using the query as a suffix. For example
     * 			5 would return all records that end in 5 but 51295 would return
     * 			all queries that end in 51295. Querying ends when the 
     *			user inputs -1
     * 
     * Pre-condition:	this.dataBin, this.hashBin, and the tree structure 
     * 					have all been initialized with all of the data
     * 
     * Post-condition:	Queries are done according to user termination
     * 
     * Parameters:	None
     * 
     * Returns:	None
     * 
     *---------------------------------------------------------------------*/
    private void beginQuerying() {
        Scanner scanner = new Scanner(System.in);
        String query;
        int queryInt = -1;
        // System.out.println("\nEnter a runnerId to search, or enter 00000000 (eight
        // zeros) to exit the program");
        // While input not "00000000"
        while ((query = scanner.nextLine()).compareTo("00000000") != 0) {
            try {
                // Parse the int and ensure >= 0
                queryInt = Integer.parseInt(query);
                if (queryInt < 0) {
                    System.out.println("Please enter a valid, non-negative integer");
                } else {
                    // If valid start at the last index of the string and set current 
                    // node to root
                    int i = query.length() - 1;
                    HashNode currentNode = root;
                    while (i >= 0) {
                        // While index is a valid and being decremented
                        try {
                            // Get the node child that corresponds to the digit at i in the query
                            currentNode = currentNode.getChild(Integer.parseInt(query.substring(i, i + 1)));
                            // If leaf node and no children then no result
                            if (currentNode.isLeaf() && currentNode.getDataCount() == 0) {
                                System.out.println("Suffixnotfound");
                                i = -1;
                            }
                            // Case where we reach end of query before end of tree
                            // Call query helper to print results
                            else if (i == 0 || currentNode.isLeaf()) {

                                this.queryHelper(query, currentNode);
                                i = -1;
                            }
                            i--;
                        } catch (Exception e) {
                            System.out.println("ERROR: query contains a non int");
                            e.printStackTrace();
                            System.exit(-1);
                        }
                    }
                }
            } catch (Exception e) {
                System.out.println("Please enter a valid, non-negative integer");
            }
        }
        // System.out.println("Goodbye!");
        scanner.close();
    }

    /*---------------------------------------------------------------------
     * Method	queryHelper
     * 
     * Purpose: Takes the final node beginQuerying has found and goes through 
     *          all its children (or none if it is a leaf )and calls printNode on those 
     *          children to print out all id's that match the query. Uses a queue to traverse
     *          the tree from the given node
     * 
     * Pre-condition: 	node aligns with the given query and neither are null
     * 
     * Post-condition:	Any id that matches the query from node or any of its children
     *                  are sent to printNode
     * 
     * Parameters:	
     *      -- query - String query suffix
     *      -- node - HashNode to start finding the leaves of 
     * 
     * Returns: void
     * 
     *---------------------------------------------------------------------*/
    private void queryHelper(String query, HashNode node) {
        // Create a queue using ArrayDeque
        ArrayDeque<HashNode> leafNodes = new ArrayDeque<>(20);
        // Add the given node to the queue
        leafNodes.offerLast(node);
        HashNode currentNode;
        while (!leafNodes.isEmpty()) {
            // While the queue has elements get the from of the queue, print that nodes 
            // children if it is a leaf, or add all its children nodes to the queue if 
            // it is not a leaf.
            currentNode = leafNodes.poll();
            if (currentNode.isLeaf()) {
                this.printNode(query, currentNode);
            } else {
                for (int i = 0; i < 10; i++) {
                    leafNodes.offerLast(currentNode.getChild(i));
                }
            }
        }

    }

    /*---------------------------------------------------------------------
     * Method	printNode
     * 
     * Purpose: Take a leaf node and find any id-offset pairs it references 
     *          that match the query and read that info from the data binary file
     *          and print it.
     * 
     * Pre-condition: 	node is a leaf node.
     * 
     * Post-condition:	lines from this.dataBin matching the query are printed 
     * 
     * Parameters:	
     *      query -- String suffix to search for
     *      node -- HashNode leaf to search for matching ids
     * 
     * Returns: void
     * 
     *---------------------------------------------------------------------*/
    private void printNode(String query, HashNode node) {
        boolean printed = false;
        // Do nothing if no elements in the node
        if (node.getDataCount() == 0) {
            return;
        }
        // Get the offset of the node and initialize an array to hold the elements 
        // read from the data file
        long offsetInBucketBin = node.getOffset();
        String[] lineStringArr = new String[this.fieldLengths.length];
        try {
            // Seek to the offset in the hash bucket binary file
            this.bucketBin.seek(offsetInBucketBin);
            for (int i = 0; i < node.getDataCount(); i++) {
                // For each element stored in the hash bucket binary file at this offset
                // read in the id and offset in data bin and check if the id ends 
                // with the query.
                int idFromBin = this.bucketBin.readInt();
                long offsetInDataBin = this.bucketBin.readLong();
                String idStringFromBin = String.valueOf(idFromBin);
                if (idStringFromBin.endsWith(query)) {
                    // If the id ends with the query, read in the data from the read in
                    // offset by accessing this.dataBin using readBinFileLineIntoArrayList
                    this.readBinFileLineIntoStringArr(this.fieldLengths, lineStringArr, offsetInDataBin);
                    // for (int k = 0; k < lineStringArr.length; k++) {
                    printed = true;
                    // System.out.print(String.format("[%s]", lineStringArr[k]));
                    //
                    // }

                    System.out.println(lineStringArr[0]);
                    // System.out.println(); // KEEP THIS FOR ADDING NEW LINE TO OUTPUT
                }

            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        if (!printed) { // If nothing printed tell the user nothing was found
            System.out.println("Suffixnotfound");
        }

    }

    /*---------------------------------------------------------------------
     * Method 	closeFiles
     * 
     * Purpose:	Close the binary files
     * 
     * Pre-condition:	binary files are open and exist
     * 
     * Post-condition:	binary files are closed
     * 
     * Parameters:	None
     * 
     * Returns:	Void
     * 
     *---------------------------------------------------------------------*/
    private void closeFiles() {
        try {
            this.bucketBin.close();
        } catch (IOException e) {
            System.out.println("ERROR: Could not close hash bucket binary file");
            System.exit(-1);
        }
        try {
            this.dataBin.close();
        } catch (IOException e) {
            System.out.println("ERROR: Could not close data binary file");
            System.exit(-1);
        }
    }


}