import numpy as np

def compare_results(python_file, java_file):
    ALL_GOOD = True

    # Load files efficiently using NumPy, handling empty lines safely
    python_lines = np.loadtxt(python_file, dtype=str, comments=None, ndmin=1)
    java_lines = np.loadtxt(java_file, dtype=str, comments=None, ndmin=1)

    # Convert to sets for fast lookup
    python_set = set(python_lines)
    java_set = set(java_lines)

    # Count occurrences of "Suffix not found"
    python_suffix_not_found = np.count_nonzero(python_lines == "Suffix not found")
    java_suffix_not_found = np.count_nonzero(java_lines == "Suffix not found")

    # Compare counts
    if python_suffix_not_found != java_suffix_not_found:
        print(f"Mismatch in 'Suffix not found' counts: Python has {python_suffix_not_found}, Java has {java_suffix_not_found}")
        ALL_GOOD = False
    else:
        print("Not found good")

    # Find differences using set operations
    missing_from_java = python_set - java_set - {"Suffix not found"}
    missing_from_python = java_set - python_set - {"Suffix not found"}

    # Display missing values
    if missing_from_python:
        ALL_GOOD = False
        print("Values in javaResults.txt but not in pythonResults.txt:")
        for value in missing_from_python:
            print(f"Missing: {value}")
    else:
        print("No missing values from javaResults.txt in pythonResults.txt")

    if missing_from_java:
        ALL_GOOD = False
        print("Values in pythonResults.txt but not in javaResults.txt:")
        for value in missing_from_java:
            print(f"Missing: {value}")
    else:
        print("No missing values from pythonResults.txt in javaResults.txt")

    print("ALL GOOD !" if ALL_GOOD else "NOT GOOD")

# Example usage
compare_results('pythonResults.txt', 'javaResults.txt')
