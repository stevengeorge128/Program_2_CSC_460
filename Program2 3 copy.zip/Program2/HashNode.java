
/** ---------------------------------------------------------------------
 * 
 * Class:           HashNode
 * 
 * Author:          Steven George
 * 
 * Purpose:         This class represents a node in the tree data structure 
 *                  in memory for Prog2. A hash node contains a reference to
 *                  10 children if it is not a leaf node, or an offset to
 *                  a location in memory in the bucket binary file if it is a 
 *                  leaf node. The class also stores the number of elements 
 *                  in the node, the value is represents (for example 
 *                  this node stores all elements that end in 0)
 * 
 * Inherits From:    None
 * 
 * Interfaces:       None
 *  ---------------------------------------------------------------------
 * 
 * Constants:       No constants of any variety
 * 
 *  ---------------------------------------------------------------------
 * 
 * Constructors:    HashNode(Long bucketFilePtr, boolean createChildren, int val)
 *                      Create a hash node that references byte location bucketFilePtr 
 *                      in the hash bucket file and contains all elements that have val
 *                      in the HashNodes level where the level refers to the index working
 *                      backwards in the ids that this node references
 * 
 * Class methods:   No static/class methods
 * 
 * Inst. Methods:   Getters: getChild, isLeaf, getDataCount, getOffset, getValue, getLevel
 * 
 *                  Setters: setChildOffset, setEmpty, setLevel
 * 
 *                  public void createChildren()
 *                      Initialize 10 children nodes
 * 
 *                  public void incrDataCount()
 *                      Increment this.dataCount by one
 * 
 *                  public String toString()
 *                      Override method for toString that returns 4 different 
 *                      strings depending on what has been initialized. See method 
 *                      comment for more info.
 * 
 *  --------------------------------------------------------------------- */

import java.util.ArrayList;
import java.util.Optional;

public class HashNode {

    // private int hashBucketFilePointer;
    // private ArrayList<HashNode> children = null;

    private Optional<Long> offsetStart = Optional.empty();
    private int value;
    private Optional<ArrayList<HashNode>> children = Optional.empty();
    private int currentDataCount = 0;
    private int level = -1;
    private boolean isLeaf = true;

    public HashNode(Long bucketFilePtr, int val) {
        if (value < 0 || value > 9) {
            System.out.println("ERROR: Invalid hash node value");
            System.exit(-1);
        }
        this.value = val;
        if (bucketFilePtr != null) { // Assign file ptr if this is a leaf node
            this.offsetStart = Optional.of(bucketFilePtr);

        }

    }

    /**
     * Create 10 children and mark this node as not a leaf
     */
    public void createChildren() {
        this.children = Optional.of(new ArrayList<HashNode>(10));
        for (int i = 0; i < 10; i++) {
            this.children.get().add(new HashNode(null, i));
        }
        this.isLeaf = false;
    }

    /**
     * Override of toString. Returns value, children, offset, isLeaf, level, and
     * data count
     * and uses 4 scenarios to determine the string to return depending on which
     * values
     * are null
     */
    @Override
    public String toString() {
        if (this.children.isEmpty()) { // If no children
            if (this.offsetStart.isEmpty()) { // And if not offset
                return String.format("value: %s, children: %s, offsets: %s, isLeaf: %s, level: %s, count: %s",
                        this.value, "not init",
                        "not init", this.isLeaf(), this.level, this.getDataCount());

            } else { // Else has offset but no children
                return String.format("value: %s, children: %s, offsets: %s, isLeaf: %s, level: %s, count: %s",
                        this.value, "not init",
                        this.offsetStart.get(), this.isLeaf(), this.level, this.getDataCount());

            }
        } else { // If has children
            if (this.offsetStart.isEmpty()) { // But not offset
                return String.format("value: %s, children: %s, offsets: %s, isLeaf: %s, level: %s, count: %s",
                        this.value, this.children.get().size(),
                        "not init", this.isLeaf(), this.level, this.getDataCount());

            }
        }
        // Has everything
        return String.format("value: %s, size: %s, offsets: %s, isLeaf: %s, level: %s, count: %s", this.value,
                this.children.get().size(),
                this.offsetStart.get(), this.isLeaf(), this.level, this.getDataCount());

    }

    /**
     * Increment data count
     */
    public void incrDataCount() {
        this.currentDataCount++;
    }

    // GETTERS

    /**
     * Getter for the child corresponding with value i
     * 
     * @param i int index
     * @return HashNode child
     */
    public HashNode getChild(int i) {
        return this.children.get().get(i);
    }

    /**
     * Getter that return if the node is a leaf
     * 
     * @return boolean
     */
    public boolean isLeaf() {
        return this.isLeaf;
    }

    /**
     * Getter for data count
     * 
     * @return int
     */
    public int getDataCount() {
        return this.currentDataCount;
    }

    /**
     * Getter for offset
     * 
     * @return long
     */
    public long getOffset() {
        return this.offsetStart.get();
    }

    /**
     * Getter for node value
     * 
     * @return int
     */
    public int getValue() {
        return this.value;
    }

    /**
     * Getter for node level
     * 
     * @return
     */
    public int getLevel() {
        return this.level;
    }

    // SETTERS

    /**
     * Set offset to long val
     * 
     * @param val
     */
    public void setChildOffset(long val) {
        if (val < 0) {
            System.out.println("ERROR: Negative offset in set child offset");
            System.exit(-1);
        }
        this.offsetStart = Optional.of(val);

    }

    /**
     * Setter to mark node as having no children
     */
    public void setEmpty() {
        this.children = Optional.empty();
        this.offsetStart = Optional.empty();
        this.isLeaf = false;

    }

    /**
     * Setter for node level
     * 
     * @param l int level to set
     */
    public void setLevel(int l) {
        this.level = l;
    }
}
