
# Function to compare the values in the two result files and check "Suffix not found"
def compare_results(python_file, java_file):
    ALL_GOOD = True
    # Read the contents of the python result file into a list (ignoring newlines and empty lines)
    with open(python_file, 'r') as f1:
        python_lines = [line.strip() for line in f1 if line.strip()]
        
    # Read the contents of the java result file into a list (ignoring newlines and empty lines)
    with open(java_file, 'r') as f2:
        java_lines = [line.strip() for line in f2 if line.strip()]
    
    # Count occurrences of "Suffix not found" in both files
    python_suffix_not_found = python_lines.count("Suffix not found")
    java_suffix_not_found = java_lines.count("Suffix not found")
    
    # Compare that the counts are the same
    if python_suffix_not_found != java_suffix_not_found:
        print(f"Mismatch in 'Suffix not found' counts: Python has {python_suffix_not_found}, Java has {java_suffix_not_found}")
        ALL_GOOD = False
    else:
        # print(f"'Suffix not found' counts match: {python_suffix_not_found} in both files")
        print("Not found good")
    # Check that each value in python file exists in java file
    missing_from_java = []
    for value in python_lines:
        
        if value != "Suffix not found" and value not in java_lines:
            missing_from_java.append(value)
    
    missing_from_python = []
    for value in java_lines:
        if value != "Suffix not found" and value not in python_lines:
            missing_from_python.append(value)

    # Display missing values

    if missing_from_python:
        ALL_GOOD = False
        print("Values in javaResults.txt but not in pythonResults.txt:")
        for value in missing_from_python:
            print(f"Missing: {value}")
    else:
        print("No missing values from javaResults.txt in pythonResults.txt")
        
        
    if missing_from_java:
        ALL_GOOD = False
        print("Values in pythonResults.txt but not in javaResults.txt:")
        for value in missing_from_java:
            print(f"Missing: {value}")
    else:
        print("No missing values from pythonResults.txt in javaResults.txt")


    if ALL_GOOD:
        print("ALL GOOD !")
    else:
        print("NOT GOOD")

# Example usage
compare_results('pythonResults.txt', 'javaResults.txt')
