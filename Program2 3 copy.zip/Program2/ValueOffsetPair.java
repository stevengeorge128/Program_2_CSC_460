/** ---------------------------------------------------------------------
 * 
 * Class:           ValueOffsetPair
 * 
 * Author:          Steven George
 * 
 * Purpose:         This class can hold a Value (a runner id) and an offset that 
 *                  contains the location of that id in the data binary file. This 
 *                  class is used to store the elements of a hash bucket in memory
 *                  when that hash bucket is being resized and its elements 
 *                  need to be rewritten. 
 * 
 * Inherits From:   None 
 * 
 * Interfaces:      None
 *  ---------------------------------------------------------------------
 * 
 * Constants:       No constants of any variety
 * 
 *  ---------------------------------------------------------------------
 * 
 * Constructors:    ValueOffsetPair(int i, long o)
 *                      Assign index or id i to this.index and offset o to 
 *                      this.offset
 * 
 * Class methods:   No static/class methods
 * 
 * Inst. Methods:   Only two getters for this.index and this.offset
 * 
 *  --------------------------------------------------------------------- */
public class ValueOffsetPair {
	
	private int index;
	private long offset;
	
	public ValueOffsetPair(int i, long o) {
		this.index = i; // Contain the index value from the binary file
		this.offset = o; // Contain the byte location in the binary file
	}
	
	public int getIndex() {
		return this.index;
	}
	
	public long getOffset() {
		return this.offset;
	}

}
